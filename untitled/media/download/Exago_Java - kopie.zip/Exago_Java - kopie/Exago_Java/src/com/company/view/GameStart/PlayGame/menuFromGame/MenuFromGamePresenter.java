package com.company.view.GameStart.PlayGame.menuFromGame;

import com.company.Model.gameSession;
import com.company.view.GameStart.PlayGame.PlayGameView;
import com.company.view.Leaderboard.LeaderboardPresenter;
import com.company.view.Leaderboard.LeaderboardView;
import com.company.view.Rules.RuleScreenPresenter;
import com.company.view.Rules.RuleScreenView;

public class MenuFromGamePresenter {

    private final MenuFromGameView view;
    private final gameSession modelName;
//    private final gameSession modelName;

//    public menuPresenter(menuView view, gameSession modelName, PlayGameView playGameView)
    public MenuFromGamePresenter(MenuFromGameView view , gameSession modelName) {
        this.view = view;
        this.modelName = modelName;
        addEventHandlers();
        updateView();
    }

    private void updateView() {
    }

    private void addEventHandlers() {
        this.view.getLeaderboard().setOnAction(event -> {
            //model.getLeaderboard();
            setLeaderboard();
            updateView();
        });

        this.view.getRules().setOnAction(event -> {
            setRulesView();
            updateView();
        });
    }

    private void setRulesView() {
        RuleScreenView ruleScreenView = new RuleScreenView();
        RuleScreenPresenter ruleScreenPresenter = new RuleScreenPresenter(ruleScreenView, modelName);
        view.getScene().setRoot(ruleScreenView);
        ruleScreenView.getScene().getWindow().setHeight(625);
        ruleScreenView.getScene().getWindow().setWidth(1000);
    }

    private void setLeaderboard() {
        LeaderboardView leaderboardView = new LeaderboardView();
        LeaderboardPresenter leaderboardPresenter = new LeaderboardPresenter(leaderboardView, modelName);
        view.getScene().setRoot(leaderboardView);
        leaderboardView.getScene().getWindow();
    }

}
