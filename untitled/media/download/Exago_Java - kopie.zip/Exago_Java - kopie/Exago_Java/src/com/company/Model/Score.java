package com.company.Model;

public class Score {
    int score = 0;

    public void incrementScores(int i){
        switch (i){
            case 1:
                incrementScoreLevel1();
                break;
            case 2:
                incrementScoreLevel2();
                break;
            case 3:
                incrementScoreLevel3();
                break;
            case 4:
                incrementScoreLevel4();
                break;
        }
    }
    void incrementScoreLevel1(){
       this.score += 25;
        System.out.println(this.score);
    }

    void incrementScoreLevel2(){
        this.score += 75;
    }
    void incrementScoreLevel3(){
        this.score += 150;
    }

    void incrementScoreLevel4(){
        this.score += 300;
    }

    public int getScore() {
        return score;
    }
}
