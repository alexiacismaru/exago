package com.company.Model;
import org.jeasy.rules.api.Rules;

import java.util.Arrays;
import java.util.Date;
import java.util.Objects;


public class gameSession {
    private final Board board = new Board();
    private boolean ActiveOrNot = false;
    private int wonOrloss = -1;
    private hexagonTile[][] hexagonTiles;
    private playerCPU participantCPU;

    private playerHuman participantPlayer;
    private final Turn turn = new Turn(this.getBoard(), this.getHexagonTiles());

    private String[][] polygonsToString;

    public hexagonTile[][] getHexagonTiles() {
        return hexagonTiles;
    }
    private String[][] pieces;

    public void initialiseGame(String name) {
        this.ActiveOrNot = true;
        hexagonTiles = board.initialiseBoard();
        participantPlayer = new playerHuman(name, turn);
        participantCPU = new playerCPU("Computor", turn);
        participantPlayer.incrementscores(1);
    }

    public Board getBoard() {
        return board;
    }


    public void playGame(long starttime, String[][] PolyGonsToString, int x, int y) {
        this.polygonsToString = PolyGonsToString;
        board.setPolygonsString(this.polygonsToString);
        if (turn.getTurn() % 2 == 0) {
            board.fillInTilePlayer(this.polygonsToString[x][y], turn.getTurn() % 2, x, y);
            turn.incrementTurn();
            turn.incrementTurnsTakenByPlayers();
            Date endDate = new Date();
            System.out.println((double) endDate.getTime());
            this.turn.calcSecondsPerTurn(starttime, endDate.getTime());
            // System.out.println(turn.getTurnsTakenByPlayer());
        } else if (turn.getTurn() % 2 != 0) {


            turn.calculateXYValue();
            board.fillInTileCPU(turn.getX(), turn.getY(), this.polygonsToString[turn.getX()][turn.getY()], turn.getTurn() % 2);

            turn.incrementTurn();
            try {
                //delay of 1 second
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

    }


    public int isWonOrloss() {
        return wonOrloss;
    }
/*
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        gameSession that = (gameSession) o;
        return wonOrloss == that.wonOrloss && board.equals(that.board)
                && Arrays.equals(hexagonTiles, that.hexagonTiles)
                && Objects.equals(participantCPU, that.participantCPU)
                && Objects.equals(participantPlayer, that.participantPlayer)
                && Objects.equals(turn, that.turn)
                && Objects.equals(modelName, that.modelName)
                && Arrays.equals(polygonsToString, that.polygonsToString);
    }

    public int hashCode() {
        StringBuilder b= new StringBuilder();
        for(int i=0; i<hexagonTiles.length; i++)
            b.append(Arrays.toString(hexagonTiles[0]));
        return b.toString().hashCode();
    }*/


    public int getTurn() {
        return turn.getTurn();
    }

    public void setTurn(int number) {
        this.turn.setTurn(number);
    }

    public int getColorDescision() {
        return hexagonTile.getColorDescision();
    }

    public Turn getTurnInstance() {
        return this.turn;
    }

    public void isWonOrloss(int setback) {
        this.wonOrloss = setback;
    }

    public void calcXYvalue() {
        turn.calculateXYValue();
    }

    public playerCPU getParticipantCPU() {
        return participantCPU;
    }

    public playerHuman getParticipantPlayer() {
        return participantPlayer;
    }

    public boolean isActiveOrNot() {
        return ActiveOrNot;
    }

    public void setActiveOrNot(boolean activeOrNot) {
        ActiveOrNot = activeOrNot;
    }
}