package com.company.Model;

public class PlayerSession extends Score {
    private Turn turn;

    private Score score = new Score();
    private String name;

    public PlayerSession(String name, Turn turnsTaken) {
        this.name = name;
        this.turn = turnsTaken;
        System.out.println(this.name);
    }

    public void setName(String name) {
        this.name = name;

    }

    public void incrementscores(int i){
        score.incrementScores(i);
    }



    public Turn getTurnsTaken(){
        return this.turn;
    }

    @Override
    public int getScore(){
        return score.getScore();
    }


}
