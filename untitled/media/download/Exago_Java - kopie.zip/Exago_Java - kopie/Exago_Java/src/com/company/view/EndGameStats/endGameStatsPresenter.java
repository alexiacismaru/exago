package com.company.view.EndGameStats;

import com.company.Model.gameSession;
import com.company.view.exagoPresenter;
import com.company.view.exagoView;
import javafx.geometry.Rectangle2D;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.stage.Screen;
import javafx.stage.Window;

import java.util.Iterator;

public class endGameStatsPresenter {
    private final endGameStatsView view;
    private final gameSession modelName;
    private XYChart.Series dataSeries1 = new XYChart.Series();

    public endGameStatsPresenter(endGameStatsView view, gameSession modelName) {
        this.view = view;
        this.modelName = modelName;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        // Add event handlers (inner classes or
        // lambdas) to view controls.
        // In the event handlers: call model methods
        // and updateView().

        this.view.getExit().setOnAction(event -> {
            this.view.getLineChart().getData().clear();
            int i=0;
            for (double o:modelName.getTurnInstance().getNumSeconds()) {

                this.modelName.getTurnInstance().getNumSeconds()[i] = 0;
                i++;
            }
            setMainWindow();


        });

    }

    private void updateView() {
        if (modelName.getTurn()%2 == 0){
            view.getTitle().setText("You win!   ");
        }else {
            view.getTitle().setText("You Lose, GAME OVER!");
        }
        // fills the view with model data
        int turn = 0;
        for (double o : modelName.getTurnInstance().getNumSeconds()) {
            //System.out.println(o);
            if (o != 0.0) {

                if (turn != 0) {
                        this.dataSeries1.getData().add(new XYChart.Data(turn, (double) o));
                }else {
                    this.dataSeries1.getData().add(new XYChart.Data(turn, 1));
                }
                turn++;
            }
        }
        this.view.getLineChart().getData().add(dataSeries1);
        this.view.getComputorScore().setText(String.format("CPU score: %d", this.modelName.getParticipantCPU().getScore()));
        this.view.getScore().setText(String.format("Your score: %d", this.modelName.getParticipantPlayer().getScore()));
    }

    public void addWindowEventHandlers() {
        Window window = view.getScene().getWindow();
        // Add event handlers to window
    }

    private void setMainWindow() {
        exagoView exagoView = new exagoView();
        exagoPresenter exagoPresenter = new exagoPresenter(exagoView, modelName);
        view.getScene().setRoot(exagoView);
        exagoView.getScene().getWindow().setWidth(1000);
        exagoView.getScene().getWindow().setHeight(650);
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        exagoView.getScene().getWindow().setX((screenBounds.getWidth() - 1000) / 2);
        exagoView.getScene().getWindow().setY((screenBounds.getHeight() - 650) / 2);
    }

}
