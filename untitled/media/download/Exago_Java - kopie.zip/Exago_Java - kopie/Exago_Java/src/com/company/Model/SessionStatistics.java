package com.company.Model;

import java.sql.*;

public class SessionStatistics {
    //This method initializes the database for the leaderboard and the save&load function on the local machine
    //The password needs to be changed to the password used for pgAdmin on the local machine
    //This method also returns a Connection object which we will use until the game ends
    public static Connection initializeDatabase() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DB2048", "postgres", "coltulderai.8");
            Statement statement = connection.createStatement();
            //This statement.execute has the sql script to create all the tables with the constraints and the sequences required
            //We use timestamp to get the date and exact moment of the game's ending
            //We use numeric(3) for playerid and boardid because there will be no more than 999 players on a local machine
            //and we use numeric(2) for the squareid since we only have ids from 1 to 16
            //We use sequences so that there's no need to hard code values
            statement.execute("""
                    CREATE TABLE game_stats (
                       game_id numeric CONSTRAINT pk_game_id PRIMARY KEY,
                        player_name varchar(50) CONSTRAINT nn_player_name NOT NULL ,
                       number_of_moves numeric(20) CONSTRAINT nn_number_of_moves NOT NULL ,
                       move_timestamp TIMESTAMPTZ NOT NULL\s
                       )
                   CREATE SEQUENCE increments Increment 1 START 1
                   INSERT INTO game_stats\s
                   VALUES (nextval('increments') , 'Elliot' , 20 , current_timestamp
                   )
                   CREATE TABLE ALL_GAME_STATS (
                   player_name varchar(50) CONSTRAINT pk_player
                   Total_no_of_sessions numeric(20),
                   
                   )
                   Create TABLE END_GAME_STATS (
                   avg_duration float,
                   move_outliers numeric(10),
                   score numeric(10),
                   avg_moves numeric(10)
                   )

                    """);
            statement.close();
            return connection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    //This method checkes to see if a saved game exists for a certain player.
    //It is used both when loading and saving a game
    //It needs a connection object to connect to the database and the name of the player that will be checked

    //This method creates a new save game instance in the database for new players.
    //It asks for a connection object to connect to the database
    //A score for the whole board
    //A name for the player
    //And the array of squares on which the game was player

    //This method replaces a save game instance in the database for recurring players.
    //It asks for a connection object to connect to the database
    //A score for the whole board
    //A name for the player
    //And the array of squares on which the game was played
    //This method loads a game from the database based on a given name
    //This method insets the values into the leaderboard table
    public static void insertValues(Connection connection, int score, String name) {

        try {
            Statement statement = connection.createStatement();
            //The statement is simple, we need the name, current timestamp and the score at the end of the game
            //statement.executeUpdate(" INSERT INTO INT_leaderboard VALUES ('" + name + "',current_timestamp," + score + ")");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    //This method retrieves the highest score on the leaderboard for all players
    public static ResultSet getScoresTable(Connection connection) {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT name, to_char(date_of_play,'YYYY-MM-DD HH:MI:SS'),score FROM int_leaderboard ORDER BY score DESC FETCH FIRST 5 ROWS ONLY ");
            return resultSet;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    //This method retrieves the highest score on the leaderboard for one player
    public static ResultSet getScoresName(Connection connection, String name) {
        try {
            Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT name, to_char(date_of_play,'YYYY-MM-DD HH:MI:SS'),score FROM int_leaderboard WHERE name='" + name + "' ORDER BY score DESC FETCH FIRST 5 ROWS ONLY ");
             return resultSet;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

}
