package com.company.Model;

import java.util.*;

public class Turn {
    private int turn = 0;
    private final Board board;
    private long[] numSeconds = new long[100];
    private int x;
    private int y;
    private final Random random = new Random();
    private hexagonTile[][] hexagonTiles;
    private int turnsTakenByPlayer = 0;
    private String[][] pieces;

    public Turn(Board board, hexagonTile[][] hexagonTiles) {
        this.board = board;
        this.hexagonTiles = hexagonTiles;
    }

    public void incrementTurn() {
        turn += 1;
        this.hexagonTiles = board.getHexagonTiles();
    }

    public int getTurn() {
        return turn;
    }

    public void setTurn(int number) {
        this.turn -= number;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    private int score;
    public int getScore(){
        return score;
    }

    public void calculateXYValue() {
        while (true) {
            this.setX(random.nextInt(0, 10));
            this.setY(random.nextInt(0, 13));
            if (hexagonTiles[this.getX()][this.getY()].isTileOrNot()) {
                if (!hexagonTiles[this.getX()][this.getY()].isFilled()) {
                    if (Objects.equals(hexagonTiles[this.getX()][this.getY()].getColor1(), "WHITE")) {
                        break;
                    }
                }
            }
        }
    }

    public void incrementTurnsTakenByPlayers() {
        this.turnsTakenByPlayer += 1;
    }

    public int getTurnsTakenByPlayer() {
        return this.turnsTakenByPlayer;
    }


    public long[] getNumSeconds() {
        return numSeconds;
    }

    public void calcSecondsPerTurn(long startDate, long Enddate) {
        if (turn == 0) {
            this.numSeconds[turn] = ((Enddate - startDate) / 1000);
        } else {

            this.numSeconds[turn - 1] = (((Enddate - startDate) / 1000));
        }
    }

}

