package com.company.view.EndGameStats;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.Text;

import javax.sound.sampled.Line;

import static javafx.scene.layout.GridPane.setHalignment;


public class endGameStatsView extends GridPane {

    private final int numColums = 6;
    private final int numRows = 8;
    private LineChart lineChart;
    private XYChart.Series dataSeries1;
    private Text score;
    private Text computorScore;
    private Text turnstaken;
    private Text title;
    private String YouOrLost;
    private NumberAxis xAxis;
    private NumberAxis yAxis;
    private Button exit;

    public endGameStatsView() {
        initialiseNodes();
        layoutNodes();

    }

    private void initialiseNodes() {

        title = new Text("You won!");
        this.turnstaken = new Text();
        this.xAxis = new NumberAxis();
        this.yAxis = new NumberAxis();
        this.lineChart = new LineChart(xAxis, yAxis);
        this.score = new Text();
        this.computorScore = new Text();
        //this.lineChart.getData().add(dataSeries1);
        this.exit = new Button("Exit");
    }

    private void layoutNodes() {
        // add/set … methods
        // Insets, padding, alignment, …
        for (int i = 0; i < numColums; i++) {
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setPercentWidth(100.0 / numColums);
            this.getColumnConstraints().add(colConst);
        }

        for (int i = 0; i < numRows; i++) {
            RowConstraints rowConst = new RowConstraints();
            rowConst.setPercentHeight(100.0 / numRows);
            this.getRowConstraints().add(rowConst);
        }
        this.setGridLinesVisible(false);
        this.setHgap(6);
        this.setVgap(6);
        this.setMinHeight(1080);

        this.add(this.title, 3, 0);
        this.add(this.score, 3, 1);
        this.add(this.computorScore, 4, 1);
        this.add(this.exit, 5, 1);
        this.add(this.turnstaken, 0, 2, 32, 1);
        this.lineChart.setMinHeight(500);
        this.lineChart.setMinWidth(800);
        this.add(this.lineChart, 1, 5);

        this.yAxis.setLabel("Seconds every turn took");
        this.xAxis.setLabel(String.format(" the number of the turn when the time was recorded\nIf you took less than a second the turn will not show up"));

        this.setPadding(new Insets(10));
        title.textAlignmentProperty();
        setHalignment(title, HPos.CENTER);
        title.setStyle("-fx-font-weight: BOLD;" +
                "-fx-font-size: 33;");
    }

    // package-private Getters
    // for controls used by Presenter

    Button getExit() {
        return exit;
    }

    String getYouOrLost() {
        return this.YouOrLost;
    }

    void setYouOrLost(String WinOrLoss) {
        this.YouOrLost = WinOrLoss;
    }

    LineChart getLineChart() {
        return this.lineChart;
    }

    Text getTitle() {
        return this.title;
    }

    Text getScore() {
        return score;
    }

    Text getComputorScore() {
        return computorScore;
    }

    Text getTurnstaken() {
        return turnstaken;
    }

    void setTurnstaken(Text turnstaken) {
        this.turnstaken = turnstaken;
    }
}

