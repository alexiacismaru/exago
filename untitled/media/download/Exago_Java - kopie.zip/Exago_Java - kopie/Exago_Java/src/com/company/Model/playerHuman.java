package com.company.Model;

import javax.swing.*;

public class playerHuman extends participant {
    private String Color = "BLUE";
    private String Username;

    public playerHuman(String name, Turn turn) {

        super(name, turn);
        setUsername(name);
    }
    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
    @Override
    public String getColor() {
        return this.Color;
    }
}
