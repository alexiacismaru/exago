package com.company.Model;

public abstract class participant extends PlayerSession {
    private String name;
    private PlayerSession playerSession;

    public participant(String name, Turn turn) {
        super(name, turn);
    }

    public String getName() {
        return name;
    }

    public abstract String getColor();
    @Override
    public int getScore(){
        return super.getScore();
    }
}
