package com.company.Model;

public class playerCPU extends participant {
    private final String color = "RED";
    private Turn turn;

    public playerCPU(String name, Turn turn) {
        super(name, turn);
        this.turn = turn;
    }

    @Override
    public String getColor() {
        return this.color;
    }

}
