package com.company.view.GameStart.PlayGame;

import com.company.Model.gameSession;
import com.company.Model.hexagonTile;
import com.company.view.EndGameStats.endGameStatsPresenter;
import com.company.view.EndGameStats.endGameStatsView;
import com.company.view.GameStart.PlayGame.menuFromGame.MenuFromGamePresenter;
import com.company.view.GameStart.PlayGame.menuFromGame.MenuFromGameView;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.util.Date;
import java.util.Objects;

public class PlayGamePresenter {
    private Date startDate;
    private long time;
    private final PlayGameView view;
    private final gameSession model;
    private final Alert a = new Alert(Alert.AlertType.NONE);
    private hexagonTile[][] hexagonTiles;

    public PlayGamePresenter(PlayGameView view, gameSession model) {
        this.view = view;
        this.model = model;
        hexagonTiles = model.getHexagonTiles();
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        // Add event handlers (inner classes or
        // lambdas) to view controls.
        // In the event handlers: call model methods
        // and updateView().
        view.getMenuButton().setOnAction(event -> {
            setSecondaryWindow();
            updateView();

        });


        for (int i = 0; i < view.getTilesPerRow(); i++) {
            for (int j = 0; j < view.getColumn(); j++) {
                int finalI = i;
                int finalJ = j;
                view.getPolygons()[i][j].setOnMouseClicked(event -> {
                    if (view.getPolygons()[finalI][finalJ].getFill() != Color.RED) {
                        model.getParticipantPlayer().incrementScores(1);
                        model.playGame(time, view.getPolygonsToString(), finalI, finalJ);
                        this.setColor(finalI, finalJ);
                        if (model.getTurn() % 2 == 1) {
                            model.getParticipantPlayer().incrementScores(1);
                            startDate = new Date();
                            time = startDate.getTime();
                            model.playGame(time, view.getPolygonsToString(), finalI, finalJ);
                            this.setColor(model.getTurnInstance().getX(), model.getTurnInstance().getY());
                        }
                        hexagonTiles = model.getHexagonTiles();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR, "You can't place a tile on the oppenents placed tile");
                        alert.setHeaderText("Minesweeper JavaFX");
                        alert.setResizable(true);
                        alert.showAndWait();
                    }

                    updateView();
                });
            }
        }

    }

    private void updateView() {
        // fills the view with model data
        //this.view.setCenter(model.getTileMap());
        // set up the visuals and a click listener for the tile
        view.FillAnchorPane();
        this.view.setCenter(view.getAnchorPane());
        if (this.winOrLoss(model.getTurn())) {
            model.setActiveOrNot(false);
            setWinOrLoseWindow();
        }
    }


    private void setSecondaryWindow() {
        MenuFromGameView menuView = new MenuFromGameView();
        MenuFromGamePresenter menuPresenter = new MenuFromGamePresenter(menuView, model);
        Scene scene = new Scene(menuView);
        Stage stage = new Stage();
        stage.setWidth(1000);
        stage.setHeight(800);
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        stage.setX((screenBounds.getWidth() - 1000) / 2);
        stage.setY((screenBounds.getHeight() - 650) / 2);
        stage.setScene(scene);
        stage.show();
    }

    private void setWinOrLoseWindow() {
        endGameStatsView endGameStatsView = new endGameStatsView();
        endGameStatsPresenter endGameStatsPresenter = new endGameStatsPresenter(endGameStatsView, model);
        view.getScene().setRoot(endGameStatsView);
        endGameStatsView.getScene().getWindow().setWidth(1000);
        endGameStatsView.getScene().getWindow().setHeight(800);
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        endGameStatsView.getScene().getWindow().setX((screenBounds.getWidth() - 1000) / 2);
        endGameStatsView.getScene().getWindow().setY((screenBounds.getHeight() - 650) / 2);
        model.isWonOrloss(-1);
    }

    public void setColor(int x, int y) {
        // set up the visuals and a click listener for the tile
        hexagonTiles = model.getHexagonTiles();
        if (!hexagonTiles[x][y].isFilled()) {
            if (Objects.equals(hexagonTiles[x][y].getColor(), "BLUE")) {
                //------------------------------------------------------
                //------------------------------------------------------
                view.setPolygonsColor("BLUE", x, y);
            } else {

                //------------------------------------------------------
                //------------------------------------------------------
                while (true) {
                    if (view.getPolygons()[x][y].getFill() != Color.BLUE && view.getPolygons()[x][y].getFill() != Color.RED) {
                        view.setPolygonsColor("RED", x, y);
                        break;
                    } else {
                        model.calcXYvalue();
                    }
                }

            }
        } else {
            int turnNumber = this.model.getTurn() - 1; // put  here
            System.out.println(this.model.getTurn() + "this is the turn number");
            if (turnNumber % 2 == 0) {
                //------------------------------------------------------
                //------------------------------------------------------
                view.setPolygonsColor("BLUE", x, y);
            } else if (turnNumber % 2 == 1) {

                //------------------------------------------------------
                //------------------------------------------------------
                while (true) {
                    if (view.getPolygons()[x][y].getFill() != Color.BLUE) {
                        view.setPolygonsColor("RED", x, y);
                        break;
                    } else {
                        model.calcXYvalue();
                    }
                }
            }
        }
    }


    public boolean winOrLoss(int turn) {
        Color color;
        if (turn % 2 == 0) {
            color = Color.BLUE;
        } else {
            color = Color.RED;
        }
        if (color == Color.BLUE) {
            for (int x = 0; x < 10; x++) {
                for (int y = 0; y < 13; y++) {
                    if (x + 3 < 10) {
                        if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                            if (Objects.equals(view.getPolygons()[x + 1][y].getFill(), color)) {

                                model.getParticipantPlayer().incrementscores(2);
                                if (Objects.equals(view.getPolygons()[x + 2][y].getFill(), color)) {

                                    model.getParticipantPlayer().incrementscores(3);
                                    if (Objects.equals(view.getPolygons()[x + 3][y].getFill(), color)) {

                                        model.getParticipantPlayer().incrementscores(4);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // descencingLeftDiagonalCheck
            for (int x = 0; x < 10; x++) {
                for (int y = 0; y < 13; y++) {
                    if (x - 2 >= 0 && y + 3 < 13) {
                        if (y % 2 == 0) {
                            // 3 , 0                                                        2  ,  1
                            // 3 , 5                                                        2  ,  6
                            if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                if (Objects.equals(view.getPolygons()[x - 1][y + 1].getFill(), color)) {
                                    model.getParticipantPlayer().incrementscores(2);
                                    // 2  , 2                                                           1  ,  3
                                    if (Objects.equals(view.getPolygons()[x - 1][y + 2].getFill(), color)) {
                                        model.getParticipantPlayer().incrementscores(3);

                                        if (Objects.equals(view.getPolygons()[x - 2][y + 3].getFill(), color)) {
                                            model.getParticipantPlayer().incrementscores(4);
                                            return true;

                                        }
                                    }
                                }
                            }
                        } else {
                            if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                if (Objects.equals(view.getPolygons()[x][y + 1].getFill(), color)) {
                                    model.getParticipantPlayer().incrementscores(2);
                                    // 2  , 2                                                           1  ,  3
                                    if (Objects.equals(view.getPolygons()[x - 1][y + 2].getFill(), color)) {

                                        model.getParticipantPlayer().incrementscores(3);
                                        if (Objects.equals(view.getPolygons()[x - 1][y + 3].getFill(), color)) {

                                            model.getParticipantPlayer().incrementscores(4);
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // descendingRightDiagonalCheck
            for (int x = 0; x < 10; x++) {
                for (int y = 0; y < 13; y++) {
                    if (x + 2 < 10 && y + 3 < 13) {
                        if (y % 2 == 0) {
                            // 3 , 0                                                        2  ,  1
                            // 3 , 5                                                        2  ,  6

                            if (Objects.equals(view.getPolygons()[x][y].getFill(), color))

                                if (Objects.equals(view.getPolygons()[x][y + 1].getFill(), color)) {
                                    model.getParticipantPlayer().incrementscores(2);
                                    System.out.println("incrementscores is run");
                                    // 2  , 2                                                           1  ,  3
                                    if (Objects.equals(view.getPolygons()[x + 1][y + 2].getFill(), color)) {
                                        model.getParticipantPlayer().incrementscores(3);

                                        if (Objects.equals(view.getPolygons()[x + 1][y + 3].getFill(), color)) {
                                            model.getParticipantPlayer().incrementscores(4);
                                            return true;
                                        }
                                    }
                                }
                        } else {
                            if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                if (Objects.equals(view.getPolygons()[x + 1][y + 1].getFill(), color)) {
                                    model.getParticipantPlayer().incrementscores(2);

                                    // 5,7  6,8  6,9    7,10
                                    if (Objects.equals(view.getPolygons()[x + 1][y + 2].getFill(), color)) {
                                        model.getParticipantPlayer().incrementscores(3);

                                        if (Objects.equals(view.getPolygons()[x + 2][y + 3].getFill(), color)) {
                                            model.getParticipantPlayer().incrementscores(4);
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            //----------------------------------------------------------------------------red----------------------------------------------------------------------------------------
        } else {
            for (int x = 0; x < 10; x++) {
                for (int y = 0; y < 13; y++) {
                    if (x + 3 < 10) {
                        if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                            if (Objects.equals(view.getPolygons()[x + 1][y].getFill(), color)) {

                                model.getParticipantCPU().incrementscores(2);
                                if (Objects.equals(view.getPolygons()[x + 2][y].getFill(), color)) {

                                    model.getParticipantCPU().incrementscores(3);
                                    if (Objects.equals(view.getPolygons()[x + 3][y].getFill(), color)) {

                                        model.getParticipantCPU().incrementscores(4);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // descencingLeftDiagonalCheck
            for (int x = 0; x < 10; x++) {
                for (int y = 0; y < 13; y++) {
                    if (x - 2 >= 0 && y + 3 < 13) {
                        if (y % 2 == 0) {
                            // 3 , 0                                                        2  ,  1
                            // 3 , 5                                                        2  ,  6
                            if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                if (Objects.equals(view.getPolygons()[x][y + 1].getFill(), color)) {
                                    model.getParticipantCPU().incrementscores(2);

                                    // 2  , 2                                                           1  ,  3
                                    if (Objects.equals(view.getPolygons()[x + 1][y + 2].getFill(), color)) {

                                        model.getParticipantCPU().incrementscores(3);

                                        if (Objects.equals(view.getPolygons()[x + 1][y + 3].getFill(), color)) {

                                            model.getParticipantCPU().incrementscores(4);
                                            return true;
                                        }
                                    }
                                }
                            } else {
                                if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                    if (Objects.equals(view.getPolygons()[x + 1][y + 1].getFill(), color)) {
                                        model.getParticipantCPU().incrementscores(2);

                                        // 5,7  6,8  6,9    7,10
                                        if (Objects.equals(view.getPolygons()[x + 1][y + 2].getFill(), color)) {
                                            model.getParticipantCPU().incrementscores(3);

                                            if (Objects.equals(view.getPolygons()[x + 2][y + 3].getFill(), color)) {
                                                model.getParticipantCPU().incrementscores(4);
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // descendingRightDiagonalCheck
            for (int x = 0; x < 10; x++) {
                for (int y = 0; y < 13; y++) {
                    if (x + 2 < 10 && y + 3 < 13) {
                        if (y % 2 == 0) {
                            // 3 , 0                                                        2  ,  1
                            // 3 , 5                                                        2  ,  6

                            if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                if (Objects.equals(view.getPolygons()[x][y + 1].getFill(), color)) {
                                    model.getParticipantCPU().incrementscores(2);

                                    // 2  , 2                                                           1  ,  3
                                    if (Objects.equals(view.getPolygons()[x + 1][y + 2].getFill(), color)) {

                                        model.getParticipantCPU().incrementscores(3);

                                        if (Objects.equals(view.getPolygons()[x + 1][y + 3].getFill(), color)) {

                                            model.getParticipantCPU().incrementscores(4);
                                            return true;
                                        }
                                    }
                                }
                            } else {
                                if (Objects.equals(view.getPolygons()[x][y].getFill(), color)) {
                                    if (Objects.equals(view.getPolygons()[x + 1][y + 1].getFill(), color)) {
                                        model.getParticipantCPU().incrementscores(2);

                                        // 5,7  6,8  6,9    7,10
                                        if (Objects.equals(view.getPolygons()[x + 1][y + 2].getFill(), color)) {
                                            model.getParticipantCPU().incrementscores(3);

                                            if (Objects.equals(view.getPolygons()[x + 2][y + 3].getFill(), color)) {
                                                model.getParticipantCPU().incrementscores(4);
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
}

