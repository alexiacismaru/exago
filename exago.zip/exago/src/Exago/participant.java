package Exago;

public abstract class participant {
    private String name;

    public String getName() {
        return name;
    }//getter

    public abstract String getColor();//abstract class that gets the colour
}

