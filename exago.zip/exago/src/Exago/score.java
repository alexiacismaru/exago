package Exago;

public class score {
}
