package com.company.view.GameStart.PlayGame;

import com.company.Model.ModelName;
import com.company.Model.hexagonTile;
import com.company.view.GameStart.PlayGame.menu.menuPresenter;
import com.company.view.GameStart.PlayGame.menu.menuView;
import com.company.view.exagoPresenter;
import com.company.view.exagoView;
import com.sun.glass.events.ViewEvent;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import org.w3c.dom.events.Event;

import java.beans.EventHandler;

public class PlayGamePresenter {
    private final PlayGameView view;
    private final ModelName model;

    public PlayGamePresenter(PlayGameView view, ModelName model) {
        this.view = view;
        this.model = model;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        // Add event handlers (inner classes or
        // lambdas) to view controls.
        // In the event handlers: call model methods
        // and updateView().
        view.getMenuButton().setOnAction(event -> {
            setSecondaryWindow();

        });

        view.setOnMouseClicked(event -> {
            System.out.println("Clicked: " + hexagonTile.getColor() + " " + model.getDisplayBoard());
        });

    }

    private void updateView() {
        // fills the view with model data
        view.setCenter(model.getDisplayBoard());
    }

    private void setSecondaryWindow() {
        menuView menuView = new menuView();
        menuPresenter menuPresenter = new menuPresenter(menuView, model,view);
        view.getScene().setRoot(menuView);
        menuView.getScene().getWindow().setWidth(1000);
        menuView.getScene().getWindow().setHeight(800);
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        menuView.getScene().getWindow().setX((screenBounds.getWidth() - 1000) / 2);
        menuView.getScene().getWindow().setY((screenBounds.getHeight() - 650) / 2);
    }


}

