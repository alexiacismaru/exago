package com.company.view.GameStart.PlayGame;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;


public class PlayGameView extends BorderPane {


    private ImageView image;
    private ImageView tile1;
    private ImageView tile2;
    private Button menuButton;





    public PlayGameView() {
        initialiseNodes();
        layoutNodes();

    }

    private void initialiseNodes() {
       //this.image = new ImageView("/FXBOARD.png");
        this.menuButton = new Button("Menu");
        this.tile1 = new ImageView("/tile.png");
        this.tile2 = new ImageView("/tile2.png");
    }

    private void layoutNodes() {
        setTop(this.menuButton);
        //setCenter(displayBoard());

    }


    ImageView getImage() {
        return image;
    }

    Button getMenuButton() {
        return menuButton;
    }

}