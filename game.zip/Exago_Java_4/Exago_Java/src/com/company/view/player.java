package com.company.view;

import java.sql.Time;
import java.util.Date;
import java.time.LocalTime;
import java.util.Date;
public class player {
        private int game_id;
        private String name;
        private int number_of_moves;
        private Date date;

        public player(){
            this.game_id= 0 ;
            this.name = "";
            this.number_of_moves = 0 ;
            this.date = new Date();
        }


        public player(String name,int wins, int loss, Date date){
            this.game_id = game_id;
            this.name = name;
            this.number_of_moves =number_of_moves;
            this.date = date;
        }

        public int getGame_id(){return game_id;}
        public void setGame_id(int gameid){this.game_id=game_id;}

        public String getName() {return name;}
        public void setName(String name) {
            this.name = name;
        }

        public int getNumber_of_moves() {
            return number_of_moves;
        }
        public void setNumber_of_moves(int wins) {
            this.number_of_moves = number_of_moves;
        }

        public Date getDate() {
            return date;
        }
        public void setDate(Date date) {
            this.date = date;
        }
    }
