/*package com.company.view.gamestatic;

import com.sun.javafx.menu.MenuItemBase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Date;

public class gamestatview extends GridPane {

    private Label title;
    private TableColumn column;
    private TableView row;
    private Button button_l;
    private Button button_r;


    //CREATING THE TABLE
    TableColumn<player, Integer> colid = new TableColumn<>("PLAYER ID");//colname

    TableColumn<player, String> colname = new TableColumn<>("NAME");//colwins

    TableColumn<player, Integer> colnumbermoves = new TableColumn<>("NUMBEROFMOVES");// colllos

    TableColumn<player, Date> coltime = new TableColumn<>("TIME IT TOOK"); //coldate
    Stage windows;
    TableView<player> table;

    //in
    public gamestatview(){
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        table = new TableView<>();
        //
        table.getColumns().addAll(colid, colname, colnumbermoves, coltime);
        //
        title = new Label("GAME STAT");
        button_l = new Button("Play again");
        button_r = new Button("Exit to main menu");

    }

    private void layoutNodes(){
        colid.setMaxWidth(300);
        colid.setCellValueFactory(new PropertyValueFactory<player, Integer>("Player_id"));

        colname.setMaxWidth(300);
        colname.setCellValueFactory(new PropertyValueFactory<player, String>("Name"));

        colnumbermoves.setMaxWidth(300);
        colnumbermoves.setCellValueFactory(new PropertyValueFactory<player, Integer>("Number_of_moves"));

        coltime.setMaxWidth(300);
        coltime.setCellValueFactory(new PropertyValueFactory<player, Date>("Time"));

        this.setPadding(new Insets(10));

        title.textAlignmentProperty();
        this.add(title, 1, 1, 3, 1);
        setHalignment(title, HPos.CENTER);
        title.setStyle("-fx-font-weight: BOLD;" +
                "-fx-font-size: 33;");

        addButtonL(button_l, 1, 1, 1, 1);
        addButtonR(button_r, 1, 7, 3, 1);
    }

    private void addButtonL(Button button, int i1, int i2, int i3, int i4) {
        this.add(button, i1, i2, i3, i4);
        button.setPrefHeight(25);
        button.setPrefWidth(200);
        button.setAlignment(Pos.BOTTOM_LEFT);
        setHalignment(button, HPos.CENTER);
        button.setStyle("-fx-font-weight: BOLD");
    }

    private void addButtonR(Button button, int i1, int i2, int i3, int i4) {
        this.add(button, i1, i2, i3, i4);
        button.setPrefHeight(25);
        button.setPrefWidth(200);
        button.setAlignment(Pos.BOTTOM_LEFT);
        setHalignment(button, HPos.CENTER);
        button.setStyle("-fx-font-weight: BOLD");
    }

    private void addLabel(Label label, int i1) {
        this.add(label, 1, i1, 3, 1);
        label.setAlignment(Pos.TOP_CENTER);
        setHalignment(label, HPos.CENTER);
        label.setStyle("-fx-font-size: 17;");
    }

    public MenuItemBase getExit() {
        return null;
    }
}
*/

