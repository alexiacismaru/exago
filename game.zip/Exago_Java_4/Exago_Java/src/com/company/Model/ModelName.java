package com.company.Model;

import com.company.view.GameStart.PlayGame.PlayGameView;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Border;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class ModelName {
    //private attributes
    private String Username;

    //---------------------------------------------------------------------------------------
    private final static int WINDOW_WIDTH = 1000;
    private final static int WINDOW_HEIGHT = 1000;

    private final static double r = 35; // the inner radius from hexagon center to outer corner
    private final static double n = Math.sqrt(r * r * 0.75); // the inner radius from hexagon center to middle of the axis
    private final static double TILE_HEIGHT = 2 * r;
    private final static double TILE_WIDTH = 2 * n;
//---------------------------------------------------------------------------------------

    public ModelName()
    {

    }

    //methods with business logc
    public AnchorPane displayBoard() {
        AnchorPane tileMap = new AnchorPane();
        Scene content = new Scene(tileMap, WINDOW_WIDTH, WINDOW_HEIGHT);
        //primaryStage.setScene(content);

        int rowCount = 13; // how many rows of tiles should be created
        int tilesPerRow = 10; // the amount of tiles that are contained in each row
        int xStartOffset = 45; // offsets the entire field to the right
        int yStartOffset = 45; // offsets the entire fiels downwards

        for (int x = 0; x < tilesPerRow; x++) {
            for (int y = 0; y < rowCount; y++) {
                if ((y == 0 || y == 12) && x >= 3 && x < 7 ||
                        (y == 1 || y == 11) && x >= 2 && x < 7 ||
                        (y == 2 || y == 10) && x >= 2 && x < 8 ||
                        (y == 3 || y == 9) && x >= 1 && x < 8 ||
                        (y == 4 || y == 8) && x >= 1 && x < 9 ||
                        (y == 5 || y == 7) && x < 9 || y == 6
                ) {
                    double xCoord = x * TILE_WIDTH + (y % 2) * n + xStartOffset;
                    double yCoord = y * TILE_HEIGHT * 0.75 + yStartOffset;

                    Polygon tile = new Tile(xCoord, yCoord);
                    tileMap.getChildren().add(tile);
                }
            }
        }
        return tileMap;
    }
    public class Tile extends Polygon {
        private hexagonTile hexagonTile;
        private Color Color;


        Tile(double x, double y) {
            // creates the polygon using the corner coordinates
            this.hexagonTile =  new hexagonTile(true,"WHITE",true);
            getPoints().addAll(
                    x, y,
                    x, y + r,
                    x + n, y + r * 1.5,
                    x + TILE_WIDTH, y + r,
                    x + TILE_WIDTH, y,
                    x + n, y - r * 0.5
            );

            // set up the visuals and a click listener for the tile
            setFill(Color.FLORALWHITE);
            setStrokeWidth(1);
            setStroke(Color.BLACK);
        }
        //needed getter and setter


        public Color getColor() {
            return Color;
        }

        public void setColor(Color color) {
            Color = color;
        }
    }
    //needed getter and setter

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public AnchorPane getDisplayBoard(){
        return displayBoard();
    }
}
