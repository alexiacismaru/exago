package com.company.Model;

public class score {
}
