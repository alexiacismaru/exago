package com.company.Model;

import java.util.Objects;
import java.util.Scanner;

public class gameSession {
    private final Board board = new Board();
    private hexagonTile[][] hexagonTiles;
    private final playerCPU participantCPU = new playerCPU();
    private final playerHuman participantPlayer = new playerHuman();
    private final Scanner scanner = new Scanner(System.in);
    private final Turn turn = new Turn(this.getBoard(), this.getHexagonTiles());


    public hexagonTile[][] getHexagonTiles() {
        return hexagonTiles;
    }

    public void initialiseGame() {
        hexagonTiles = board.initialiseBoard();
        participantPlayer.setColor(participantCPU.setColor());
        this.displayGame();
        SessionStatistics.initializeDatabase();
    }

    public Board getBoard() {
        return board;
    }

    public void displayGame() {
        System.out.println("\t1\t\t2\t\t3\t\t4\t\t5\t\t6\t\t7\t\t8\t\t9\t\t10");
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 10; j++) {
                if (j == 0) {
                    System.out.print(i + 1 + "\t");
                }
                if (hexagonTiles[i][j].getColor() == null) {

                    System.out.printf("%5s\t", "~");
                }
                if (hexagonTiles[i][j].getColor() != null) {
                    System.out.printf("%5s\t", hexagonTiles[i][j].getColor());
                }
                if (j == 9) {
                    System.out.println();
                }
            }
        }
        System.out.println();
    }

    public String playGame() {

        if (turn.getTurn() % 2 == 0) {
            board.fillInTilePlayer(participantPlayer.getColor());
            turn.incrementTurn();
            if (this.winOrLoss(this.hexagonTiles, participantPlayer.getColor())) {
                return "The player won!";
            }
            this.displayGame();
        } else if (turn.getTurn() % 2 != 0) {
            turn.calculateXYValue();
            board.fillInTileCPU(participantCPU.getColor(), turn.getX(), turn.getY());
            if (this.winOrLoss(this.hexagonTiles, participantCPU.getColor())) {
                return "The CPU won!\n GAME OVER";
            }
            turn.incrementTurn();
            this.displayGame();
        }
        return "";
    }

    public boolean winOrLoss(hexagonTile[][] hexagonTiles1, String color) {
        // horizontalCheck
        for (int i = 0; i < board.getMAX_AMOUNTXARRAY() ; i++) {
            for (int j = 0; j < board.getMAX_AMOUNTY(); j++) {
                if (!(j+1 >= board.getMAX_AMOUNTY() || j+2 >= board.getMAX_AMOUNTY() || j+3 >= board.getMAX_AMOUNTY())) {
                    if (Objects.equals(hexagonTiles1[i][j].getColor(), color) && Objects.equals(hexagonTiles1[i][j + 1].getColor(), color)
                            && Objects.equals(hexagonTiles1[i][j + 2].getColor(), color) && Objects.equals(hexagonTiles1[i][j + 3].getColor(), color)) {
                        return true;
                    }
                }
            }
        }
        // verticalCheck
        for (int i = 0; i < board.getMAX_AMOUNTXARRAY() - 3; i++) {
            for (int j = 0; j < board.getMAX_AMOUNTY(); j++) {
                if (!(i >= board.getMAX_AMOUNTY() || j >= board.getMAX_AMOUNTXARRAY())) {
                    if (Objects.equals(hexagonTiles1[i][j].getColor(), color) && Objects.equals(hexagonTiles1[i + 1][j].getColor(), color)
                            && Objects.equals(hexagonTiles1[i + 2][j].getColor(), color) && Objects.equals(hexagonTiles1[i + 3][j].getColor(), color)) {
                        return true;
                    }
                }
            }
        }
        // ascendingDiagonalCheck
        for (int i = 3; i < board.getMAX_AMOUNTXARRAY(); i++) {
            for (int j = 0; j < board.getMAX_AMOUNTY() - 3; j++) {
                if (!(i >= board.getMAX_AMOUNTY() || j >= board.getMAX_AMOUNTXARRAY())) {
                    if (Objects.equals(hexagonTiles1[i][j].getColor(), color) && Objects.equals(hexagonTiles1[i - 1][j + 1].getColor(), color)
                            && Objects.equals(hexagonTiles1[i - 2][j + 2].getColor(), color) && Objects.equals(hexagonTiles1[i - 3][j + 3].getColor(), color)) {
                        return true;
                    }
                }
            }
        }
        // descendingDiagonalCheck
        for (int i = 3; i < board.getMAX_AMOUNTXARRAY(); i++) {
            for (int j = 3; j < board.getMAX_AMOUNTY(); j++) {
                if (!(i >= board.getMAX_AMOUNTY() || j >= board.getMAX_AMOUNTXARRAY())) {
                    if (Objects.equals(hexagonTiles1[i][j].getColor(), color) && Objects.equals(hexagonTiles1[i - 1][j - 1].getColor(), color)
                            && Objects.equals(hexagonTiles1[i - 2][j - 2].getColor(), color) && Objects.equals(hexagonTiles1[i - 3][j - 3].getColor(), color)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}