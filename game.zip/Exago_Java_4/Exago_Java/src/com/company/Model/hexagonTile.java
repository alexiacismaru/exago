package com.company.Model;

public class hexagonTile {
    private boolean tileOrNot;
    private static String Color;
    private boolean filled;

    public hexagonTile(boolean tileOrNot, String color, boolean filled) {
        this.tileOrNot = tileOrNot;
        this.Color = color;
        this.filled = filled;
    }

    public hexagonTile(String color, boolean filled) {
        Color = color;
        this.filled = filled;
    }

    public hexagonTile(boolean tileOrNot) {
        this.tileOrNot = tileOrNot;
    }

    public boolean isTileOrNot() {
        return tileOrNot;
    }

    public void setTileOrNot(boolean tileOrNot) {
        this.tileOrNot = tileOrNot;
    }

    public static String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }
}
