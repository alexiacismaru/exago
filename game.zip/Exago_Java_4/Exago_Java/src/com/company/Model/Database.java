package com.company.Model;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;

/*public class Database {
    public static boolean updateDatabase(String userName){
        try {
            Connection connection   = SessionStatistics.initializeDatabase();
            Statement statement = connection.createStatement();

            statement.close();
            return false;
    } catch (SQLException e){

        }
}}


*/