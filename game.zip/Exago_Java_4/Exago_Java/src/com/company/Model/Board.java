package com.company.Model;

import java.util.Objects;
import java.util.Scanner;

public class Board {
    private final int MAX_AMOUNTY = 10;
    private final int MAX_AMOUNTX = 12;
    private final int MAX_AMOUNTXARRAY = 13;
    private final int MIN_AMOUNT = 0;

    public int getMAX_AMOUNTY() {
        return MAX_AMOUNTY;
    }

    public int getMAX_AMOUNTXARRAY() {
        return MAX_AMOUNTXARRAY;
    }

    private final hexagonTile[][] hexagonTiles = new hexagonTile[MAX_AMOUNTXARRAY][MAX_AMOUNTY];
    private final Scanner scanner = new Scanner(System.in);

    public hexagonTile[][] initialiseBoard() {
        for (int i = 0; i < MAX_AMOUNTXARRAY; i++) {
            for (int j = 0; j < MAX_AMOUNTY; j++) {
                if (
                        (i == MIN_AMOUNT || i == MAX_AMOUNTX) && j > MIN_AMOUNT + 2 && j < MAX_AMOUNTY - 3 || (i == MIN_AMOUNT + 1
                                || i == MAX_AMOUNTX - 1) && j > MIN_AMOUNT + 2 && j < MAX_AMOUNTY - 2
                                || (i == MIN_AMOUNT + 2 || i == MAX_AMOUNTX - 2) && j > MIN_AMOUNT + 1 && j < MAX_AMOUNTY - 2
                                || (i == MIN_AMOUNT + 3 || i == MAX_AMOUNTX - 3) && j > MIN_AMOUNT + 1 && j < MAX_AMOUNTY - 1
                                || (i == MIN_AMOUNT + 4 || i == MAX_AMOUNTX - 4) && j > MIN_AMOUNT + 1
                                || (i == MIN_AMOUNT + 5 || i == MAX_AMOUNTX - 5) && j > MIN_AMOUNT
                                || i == MIN_AMOUNT + 6
                ) {
                    System.out.println(i + " " + j);
                    hexagonTiles[i][j] = new hexagonTile(true, "White", false);
                } else {
                    hexagonTiles[i][j] = new hexagonTile(false);
                }

            }
        }
        return hexagonTiles;
    }

    public hexagonTile[][] getHexagonTiles() {
        return hexagonTiles;
    }

    public void fillInTilePlayer(String color) {


        while (true) {
            int y;
            int x;
            System.out.println("give an X value");
            x = scanner.nextInt() - 1;
            System.out.println("give an Y value");
            y = scanner.nextInt() - 1;
            if ((x <= MAX_AMOUNTX && y <= MAX_AMOUNTY) && (x >= MIN_AMOUNT && y >= MIN_AMOUNT)) {
                if (Objects.equals(hexagonTiles[x][y].getColor(), "White")) {
                    hexagonTiles[x][y].setColor(color);
                    hexagonTiles[x][y].setFilled(true);
                    break;
                } else if (Objects.equals(hexagonTiles[x][y].getColor(), null)) {
                    System.out.println("THIS IS NOT A TILE");
                } else {
                    System.out.println("this tile is already filled in");
                }
            } else if ((x < MIN_AMOUNT || MAX_AMOUNTX < x) && (y > MIN_AMOUNT && MAX_AMOUNTX > y)) {
                System.out.printf("%d is not in bounds\n", x + 1);
            } else if ((y < MIN_AMOUNT || MAX_AMOUNTX < y) && (x > MIN_AMOUNT && MAX_AMOUNTX > x)) {
                System.out.printf("%d is not in bounds\n", x + 1);
            } else {
                System.out.printf("%d, %d is not in bounds\n", x + 1, y + 1);
            }
        }
    }

    public void fillInTileCPU(String color, int i, int j) {
        i -= 1;
        j -= 1;
        System.out.println(i + "   " + j);
        if (Objects.equals(hexagonTiles[i][j].getColor(), "White") && hexagonTiles[i][j].isTileOrNot()) {
            hexagonTiles[i][j].setColor(color);
            hexagonTiles[i][j].setFilled(true);
        }
    }


}
