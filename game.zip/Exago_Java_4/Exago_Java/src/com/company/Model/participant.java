package com.company.Model;

public abstract class participant {
    private String name;

    public String getName() {
        return name;
    }

    public abstract String getColor();
}
