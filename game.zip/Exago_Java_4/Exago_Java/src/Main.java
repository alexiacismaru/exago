import com.company.Model.gameSession;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        gameSession gameSession = new gameSession();

        gameSession.initialiseGame();
        while (true) {
            System.out.printf("%s\n",gameSession.playGame());
        }
    }
}
