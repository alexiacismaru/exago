
Create TABLE IF NOT EXISTS ALL_GAME_STATS
(
    player_name varchar(50) CONSTRAINT pk_player PRIMARY KEY ,
    win numeric (5),
    loss numeric (5),
    date timestamptz
);

Create TABLE IF NOT EXISTS END_GAME_STATS
(
    game_id numeric (3) CONSTRAINT pk_game_id PRIMARY KEY,
    player_name varchar(50)  ,
    number_of_moves numeric(20) CONSTRAINT nn_number_of_moves NOT NULL ,
    game_timestamp TIMESTAMP NOT NULL,
    FOREIGN KEY (player_name) REFERENCES ALL_GAME_STATS(player_name)
);

INSERT INTO ALL_GAME_STATS
VALUES ('asdf',3,8,current_timestamp);
INSERT INTO ALL_GAME_STATS
VALUES ('STEVEE' , 1,9,'current_timestamp');
INSERT INTO ALL_GAME_STATS
VALUES ('MIKEYY', 3,9,'current_timestamp');
Select * FROM ALL_GAME_STATS;
Select * FROM END_GAME_STATS;



INSERT INTO END_GAME_STATS
VALUES (0007,'STEVEE',734,current_timestamp);
INSERT INTO END_GAME_STATS
VALUES (0002,'MIKEYY',436,current_timestamp);
INSERT INTO END_GAME_STATS
VALUES (0006,'asdf',836,current_timestamp);

